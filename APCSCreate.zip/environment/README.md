4/3-5 working on making button work, new page, button css like graphic designing 
4/10 working no code thinkign about what i should do, trying to pring and get rid of undefine
4/13 decide to do soething else because too boring, came up with idea of circles floating and something chasing after it and then that will play music
4/17 drawing circles, the draw circle doesnt work and thinking why function DrawCircle(x,y,radius, startangle,endangle){
    var canvas = document.getElementById("mainCanvas");
    var ctx = canvas.getContext("2d");
    ctx.beginPath();
    ctx.arc(x,y,radius,startangle,endangle)
    //ctx.arc(100, 75, 50, 0, 2 * Math.PI); //x,y,radius, start angle,end angle
    ctx.fillStyle = "red";
    Decide not to draw circle and use pictures of emojis instead of drawing
4/18 was thinking setting initial position and then moving it. Decide to use objects for emoji. Need to find pictures that is not copyright.
4/19 Use cloud 9 again changing back and forth and thinking are some pic copyright, just testing out and maybe later find real pic, i resize pic
using cloud 9. Everything crash, and idk y and thinking about what i should do. Objects or Arrays. Emoji move and I drew the binary picture adn it was able to move. It was not or a bit difficult 
to change the position of binary picture and telling it not to go off the screen. Thinking about making the emoji move away from the pic. Something really hard for me is the time i have left to 
do this, maybe should have been better at time managment. It was fun programming but got other stuff to do but i think ill continue tmr? or hmm. it's fun.
4/24-25 wrote code and found new image that are label for reuse, made the collision work. Made new html page so there will be a link to the sources of where i got the images from
-Work with tone.js and got a note to play when the binary picture touch the emojis, thinking of making more beautiful sounds
abstraction- something call a bunch of function
algorithm- mathish things
4/26 thinking of playing like a song ish or short melody, trying to let random notes play, array of events. Too much work, not enough time, try to finish today, thinking of how to make the game end or something
-catch all emoji then the games end, there wont be anyscore just a game to liven up your day
-when all emoji catch, a pop up screen will appear and can ask if you want to play again
-Write rules and maybe put a back ground
= got the pop up screen to work
4/29 continue working and thinking it was hard to like put idea together,
-like how to make emoji move, picture move, random postition or velocity, making sounds, limits to where the emoji can move, the box where the emoji go and then bounce off.
-change from array to object
-at first just fill in circle but then thought printing pictures would just be easier
-also difference instrument sounds and using new audio thingie but then change to tone.js because it already have store sounds of piano, sythesizerish things
4/30 change some function so it match with the collegeboard function. for ex made a new function